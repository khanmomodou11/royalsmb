<template>
    <div>
        {{ trans('em.accept_cookie') }} {{ trans('em.privacy') }}
    </div>
</template>